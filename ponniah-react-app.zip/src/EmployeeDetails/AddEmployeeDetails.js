import React,{Component} from "react";
import "./styles/EmployeeDetails.css";


export default class AddEmployeeDetails extends Component{
    constructor(props){
        super(props)     
        this.state={
            employeeRecord:{},
            firstName:""
        }  
      }
      componentDidUpdate(){
          console.log("Input :",this.state.firstName);
      }
      firstNameChange(e){
          console.log("Event Trigeered",e.target.value);
          this.setState({firstName:e.target.value});
          console.log(this.state.firstName);
      }
    render(){
        return(
            <div className="popup-section">
                <div className="popup-background"></div>
                <div className="popup-body">
                    <div className="popup-body-header">Create New Employee Record</div>
                    <form>
                        <label>First Name:</label>
                        <input id="first" type="text" onChange={this.firstNameChange.bind(this)} value={this.state.firstName}/>
                    </form>
                </div>
            </div>
        )
    }
}